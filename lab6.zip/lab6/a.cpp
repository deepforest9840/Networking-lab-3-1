#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int ar[n];
        int br[n];
        for(int i=0;i<n;i++){
            cin>>ar[i];
        }
        sort(ar,ar+n);
        int k=ceil(n/2.0)-1;
        int mid=ar[k];
        int op=0;
       // cout<<n<<k<<endl;
        for(k;k<n;k++){
            //cout<<ar[k]<<" ";
            if(mid<ar[k]){
                break;
            }
            
            op++;
        }

        cout<<op<<endl;
    }
}