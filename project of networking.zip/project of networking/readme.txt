To run the project:
1.python3 server.py localhost(or your ip address) portnumber
2.python3 server.py localhost(or your server ip address) portnumber


