import socket  # Importing the socket module for network communication
import threading  # Importing threading for concurrent execution
import pickle  # Importing pickle for serialization
import os  # Importing os module for file operations
import sys  # Importing sys module for command line arguments

groups = {}  # Dictionary to store group information
fileTransferCondition = threading.Condition()  # Condition variable for file transfer synchronization


class Group:
    """
    Class representing a group of users
    """

    def __init__(self, admin, client):
        """
        Initialize group with admin user and client connection
        """
        self.admin = admin  # Admin username
        self.clients = {admin: client}  # Dictionary to store connected clients
        self.offlineMessages = {}  # Dictionary to store offline messages
        self.allMembers = set()  # Set to store all group members
        self.onlineMembers = set()  # Set to store online members
        self.joinRequests = set()  # Set to store join requests
        self.waitClients = {}  # Dictionary to store clients waiting for approval

        self.allMembers.add(admin)  # Add admin to allMembers set
        self.onlineMembers.add(admin)  # Add admin to onlineMembers set

    def disconnect(self, username):
        """
        Disconnect a user from the group
        """
        self.onlineMembers.remove(username)  # Remove user from onlineMembers set
        del self.clients[username]  # Remove client connection

    def connect(self, username, client):
        """
        Connect a user to the group
        """
        self.onlineMembers.add(username)  # Add user to onlineMembers set
        self.clients[username] = client  # Add client connection

    def sendMessage(self, message, username):
        """
        Send message to all members of the group
        """
        for member in self.onlineMembers:
            if member != username:
                # Send message to each member except the sender
                self.clients[member].send(bytes(username + ": " + message, "utf-8"))


def Chat(client, username, groupname):
    """
    Chat function to handle communication with clients
    """
    while True:
        msg = client.recv(1024).decode("utf-8")  # Receive message from client
        if msg == "/viewRequests":
            # View join requests
            # Implementation not included for brevity
            pass
        elif msg == "/approveRequest":
            # Approve join request
            # Implementation not included for brevity
            pass
        elif msg == "/disconnect":
            # Disconnect user
            # Implementation not included for brevity
            pass
        elif msg == "/messageSend":
            # Send message to group
            # Implementation not included for brevity
            pass
        elif msg == "/waitDisconnect":
            # Disconnect waiting client
            # Implementation not included for brevity
            pass
        elif msg == "/allMembers":
            # Get all group members
            # Implementation not included for brevity
            pass
        elif msg == "/onlineMembers":
            # Get online group members
            # Implementation not included for brevity
            pass
        elif msg == "/changeAdmin":
            # Change group admin
            # Implementation not included for brevity
            pass
        elif msg == "/whoAdmin":
            # Get group admin
            # Implementation not included for brevity
            pass
        elif msg == "/kickMember":
            # Kick member from group
            # Implementation not included for brevity
            pass
        elif msg == "/fileTransfer":
            # Initiate file transfer
            # Implementation not included for brevity
            pass
        elif msg == "/sendFilename" or msg == "/sendFile":
            # Send filename or file
            # Implementation not included for brevity
            pass
        else:
            print("UNIDENTIFIED COMMAND:", msg)  # Print unidentified command


def handshake(client):
    """
    Handshake function to handle initial client-server interaction
    """
    username = client.recv(1024).decode("utf-8")  # Receive username from client
    client.send(b"/sendGroupname")  # Send signal to request group name from client
    groupname = client.recv(1024).decode("utf-8")  # Receive group name from client
    if groupname in groups:
        if username in groups[groupname].allMembers:
            # Connect user to group if already a member
            groups[groupname].connect(username, client)
            client.send(b"/ready")  # Send signal to indicate readiness
            print("User Connected:", username, "| Group:", groupname)
        else:
            # Add user to join requests if not already a member
            groups[groupname].joinRequests.add(username)
            groups[groupname].waitClients[username] = client
            # Send message to group members about join request
            groups[groupname].sendMessage(username + " has requested to join the group.", "NetConnect")
            client.send(b"/wait")  # Send signal to indicate waiting
            print("Join Request:", username, "| Group:", groupname)
        threading.Thread(target=Chat, args=(client, username, groupname,)).start()  # Start chat thread
    else:
        # Create new group if group does not exist
        groups[groupname] = Group(username, client)
        threading.Thread(target=Chat, args=(client, username, groupname,)).start()  # Start chat thread
        client.send(b"/adminReady")  # Send signal to indicate admin readiness
        print("New Group:", groupname, "| Admin:", username)


def main():
    """
    Main function to start the server
    """
    if len(sys.argv) < 3:
        # Check for command line arguments
        print("USAGE: python server.py <IP> <Port>")
        print("EXAMPLE: python server.py localhost 8000")
        return
    listenSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Create TCP socket
    listenSocket.bind((sys.argv[1], int(sys.argv[2])))  # Bind socket to address
    listenSocket.listen(10)  # Listen for incoming connections with a backlog of 10
    print("NetConnect Server is running")
    while True:
        client, _ = listenSocket.accept()  # Accept new client connection
        threading.Thread(target=handshake, args=(client,)).start()  # Start handshake thread


if __name__ == "__main__":
    main()  # Call main function if script is executed directly
